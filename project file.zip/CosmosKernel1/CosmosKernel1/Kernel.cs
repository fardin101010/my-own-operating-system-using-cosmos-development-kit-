﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Sys = Cosmos.System;
using Cosmos.System.FileSystem;
using Cosmos.System.FileSystem.VFS;

namespace CosmosKernel1
{
    public class Kernel : Sys.Kernel
    {
        private Dictionary<string, (string content, int size)> fileSystem;
        private HashSet<string> permissions;
        private Queue<string> processQueue;
        private Dictionary<string, string> interProcessCommunication;
        private List<string> rrQueue;
        private List<(string process, int priority)> priorityQueue;
        private Dictionary<string, int> sjfQueue;
        private Dictionary<int, Queue<string>> mlfqQueues;
        private int mlfqLevels;
        private Dictionary<string, int> processMemory;
        private List<string> edgeTasks;
        private const string FileSystemPath = @"0:\filesystem.txt";

        protected override void BeforeRun()
        {
            Console.WriteLine("Welcome to Fardin Roktim Mims Operating System.");

            fileSystem = new Dictionary<string, (string content, int size)>();
            permissions = new HashSet<string>();
            processQueue = new Queue<string>();
            interProcessCommunication = new Dictionary<string, string>();
            rrQueue = new List<string>();
            priorityQueue = new List<(string process, int priority)>();
            sjfQueue = new Dictionary<string, int>();
            mlfqQueues = new Dictionary<int, Queue<string>>();
            processMemory = new Dictionary<string, int>();
            edgeTasks = new List<string>();

            mlfqLevels = 3; // Example: 3 levels for MLFQ
            for (int i = 0; i < mlfqLevels; i++)
            {
                mlfqQueues.Add(i, new Queue<string>());
            }

            // Initialize the VFS
            VFSManager.RegisterVFS(new CosmosVFS());

            LoadFileSystem();
        }

        protected override void Run()
        {
            Console.Write("Input: ");
            var input = Console.ReadLine();
            Console.WriteLine($"You typed: \"{input}\"");

            string[] commandParts = input.Split(' ');

            try
            {
                if (commandParts.Length == 5 && commandParts[0] == "fardin" && commandParts[1] == "roktim" && commandParts[2] == "mim" && commandParts[3] == "+x")
                {
                    string fileName = commandParts[4];
                    permissions.Add(fileName);
                    Console.WriteLine($"Permission granted for file '{fileName}'.");
                }
                else if (commandParts.Length >= 2 && (commandParts[0] == "read" || commandParts[0] == "update" || commandParts[0] == "delete" || commandParts[0] == "echo"))
                {
                    string fileName = commandParts[1];
                    if (permissions.Contains(fileName))
                    {
                        if (commandParts[0] == "read")
                        {
                            ReadFile(fileName);
                        }
                        else if (commandParts[0] == "update")
                        {
                            string newContent = string.Join(" ", commandParts, 2, commandParts.Length - 2);
                            UpdateFileContent(fileName, newContent);
                        }
                        else if (commandParts[0] == "delete")
                        {
                            DeleteFile(fileName);
                        }
                        else if (commandParts[0] == "echo")
                        {
                            string content = string.Join(" ", commandParts, 2, commandParts.Length - 2);
                            EchoToFile(fileName, content);
                        }
                    }
                    else
                    {
                        Console.WriteLine($"No permission granted for file '{fileName}'.");
                    }
                }
                else if (commandParts.Length >= 2 && commandParts[0] == "mkfile")
                {
                    string fileName = commandParts[1];
                    CreateEmptyFile(fileName);
                }
                else if (commandParts.Length >= 3 && commandParts[0] == "create")
                {
                    string fileName = commandParts[1];
                    string content = string.Join(" ", commandParts, 2, commandParts.Length - 2);
                    CreateFile(fileName, content);
                }
                else if (commandParts.Length == 3 && commandParts[0] == "rename")
                {
                    string oldFileName = commandParts[1];
                    string newFileName = commandParts[2];
                    RenameFile(oldFileName, newFileName);
                }
                else if (input == "ls")
                {
                    ListFiles();
                }
                else if (input == "shutdown")
                {
                    Shutdown();
                }
                else if (input == "date")
                {
                    ShowDate();
                }
                else if (input == "time")
                {
                    ShowTime();
                }
                else if (commandParts.Length >= 2 && commandParts[0] == "schedule")
                {
                    if (commandParts[1] == "rr" && commandParts.Length == 4)
                    {
                        ScheduleRR(commandParts[2], int.Parse(commandParts[3]));
                    }
                    else if (commandParts[1] == "fcfs" && commandParts.Length == 4)
                    {
                        ScheduleFCFS(commandParts[2], int.Parse(commandParts[3]));
                    }
                    else if (commandParts[1] == "sjf" && commandParts.Length == 4)
                    {
                        ScheduleSJF(commandParts[2], int.Parse(commandParts[3]));
                    }
                    else if (commandParts[1] == "mlfq" && commandParts.Length == 5)
                    {
                        ScheduleMLFQ(commandParts[2], int.Parse(commandParts[3]), int.Parse(commandParts[4]));
                    }
                    else if (commandParts[1] == "priority" && commandParts.Length == 5)
                    {
                        SchedulePriority(commandParts[2], int.Parse(commandParts[3]), int.Parse(commandParts[4]));
                    }
                    else
                    {
                        Console.WriteLine("Invalid scheduling command.");
                    }
                }
                else if (commandParts.Length >= 4 && commandParts[0] == "ipc")
                {
                    string sender = commandParts[1];
                    string receiver = commandParts[2];
                    string message = string.Join(" ", commandParts, 3, commandParts.Length - 3);
                    SendMessage(sender, receiver, message);
                }
                else if (input == "show all process")
                {
                    ShowAllProcesses();
                }
                else if (commandParts.Length >= 2 && commandParts[0] == "meminfo")
                {
                    DisplayMemoryInfo();
                }
                else if (commandParts.Length >= 2 && commandParts[0] == "edge")
                {
                    HandleEdgeTaskCommands(commandParts);
                }
                else if (commandParts.Length == 2 && commandParts[0] == "size")
                {
                    string fileName = commandParts[1];
                    ShowFileSize(fileName);
                }
                else
                {
                    Console.WriteLine("Command not recognized or insufficient permissions.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        private void CreateEmptyFile(string fileName)
        {
            if (!fileSystem.ContainsKey(fileName))
            {
                fileSystem.Add(fileName, ("", 0));
                Console.WriteLine($"Empty file '{fileName}' created successfully.");
            }
            else
            {
                Console.WriteLine($"File '{fileName}' already exists.");
            }
        }

        private void CreateFile(string fileName, string content = "")
        {
            if (!fileSystem.ContainsKey(fileName))
            {
                fileSystem.Add(fileName, (content, content.Length));
                Console.WriteLine($"File '{fileName}' created successfully.");
            }
            else
            {
                Console.WriteLine($"File '{fileName}' already exists.");
            }
        }

        private void ReadFile(string fileName)
        {
            if (fileSystem.ContainsKey(fileName))
            {
                Console.WriteLine($"Content of file '{fileName}': {fileSystem[fileName].content}");
            }
            else
            {
                Console.WriteLine($"File '{fileName}' not found.");
            }
        }

        private void DeleteFile(string fileName)
        {
            if (fileSystem.ContainsKey(fileName))
            {
                fileSystem.Remove(fileName);
                Console.WriteLine($"File '{fileName}' deleted successfully.");
            }
            else
            {
                Console.WriteLine($"File '{fileName}' not found.");
            }
        }

        private void ListFiles()
        {
            Console.WriteLine("List of files:");
            foreach (var fileName in fileSystem.Keys)
            {
                Console.WriteLine(fileName);
            }
        }

        private void EchoToFile(string fileName, string content)
        {
            if (fileSystem.ContainsKey(fileName))
            {
                var fileData = fileSystem[fileName];
                fileData.content += content;
                fileData.size = fileData.content.Length;
                fileSystem[fileName] = fileData;
                Console.WriteLine($"Content echoed to file '{fileName}' successfully.");
            }
            else
            {
                Console.WriteLine($"File '{fileName}' not found.");
            }
        }

        private void UpdateFileContent(string fileName, string newContent)
        {
            if (fileSystem.ContainsKey(fileName))
            {
                fileSystem[fileName] = (newContent, newContent.Length);
                Console.WriteLine($"Content of file '{fileName}' updated successfully.");
            }
            else
            {
                Console.WriteLine($"File '{fileName}' not found.");
            }
        }

        private void RenameFile(string oldFileName, string newFileName)
        {
            if (fileSystem.ContainsKey(oldFileName))
            {
                var fileData = fileSystem[oldFileName];
                fileSystem.Remove(oldFileName);
                fileSystem.Add(newFileName, fileData);
                Console.WriteLine($"File '{oldFileName}' renamed to '{newFileName}' successfully.");
            }
            else
            {
                Console.WriteLine($"File '{oldFileName}' not found.");
            }
        }

        private void Shutdown()
        {
            SaveFileSystem();
            Console.WriteLine("Shutting down...");
            Cosmos.System.Power.Shutdown();
        }

        private void ShowDate()
        {
            DateTime currentDate = DateTime.Now;
            Console.WriteLine($"Current date: {currentDate.ToShortDateString()}");
        }

        private void ShowTime()
        {
            DateTime currentTime = DateTime.Now;
            Console.WriteLine($"Current time: {currentTime.ToLongTimeString()}");
        }

        private void ScheduleRR(string process, int memory)
        {
            rrQueue.Add(process);
            AllocateMemory(process, memory);
            Console.WriteLine($"Process '{process}' scheduled for Round Robin with {memory} KB memory.");
        }

        private void ScheduleFCFS(string process, int memory)
        {
            processQueue.Enqueue(process);
            AllocateMemory(process, memory);
            Console.WriteLine($"Process '{process}' scheduled for First Come First Serve with {memory} KB memory.");
        }

        private void ScheduleSJF(string process, int burstTime)
        {
            sjfQueue.Add(process, burstTime);
            Console.WriteLine($"Process '{process}' scheduled for Shortest Job First with burst time {burstTime}.");
        }

        private void ScheduleMLFQ(string process, int level, int memory)
        {
            if (level < mlfqLevels)
            {
                mlfqQueues[level].Enqueue(process);
                AllocateMemory(process, memory);
                Console.WriteLine($"Process '{process}' scheduled for MLFQ at level {level} with {memory} KB memory.");
            }
            else
            {
                Console.WriteLine($"Invalid MLFQ level {level}.");
            }
        }

        private void SchedulePriority(string process, int priority, int memory)
        {
            priorityQueue.Add((process, priority));
            AllocateMemory(process, memory);
            Console.WriteLine($"Process '{process}' scheduled for Priority Scheduling with priority {priority} and {memory} KB memory.");
        }

        private void AllocateMemory(string process, int memory)
        {
            if (processMemory.ContainsKey(process))
            {
                processMemory[process] = memory;
            }
            else
            {
                processMemory.Add(process, memory);
            }
        }

        private void ShowAllProcesses()
        {
            Console.WriteLine("List of all processes with allocated memory:");
            foreach (var process in processMemory)
            {
                Console.WriteLine($"Process: {process.Key}, Memory: {process.Value} KB");
            }

            // Also list processes in all scheduling queues
            Console.WriteLine("Round Robin Queue:");
            foreach (var process in rrQueue)
            {
                Console.WriteLine(process);
            }

            Console.WriteLine("First Come First Serve Queue:");
            foreach (var process in processQueue)
            {
                Console.WriteLine(process);
            }

            Console.WriteLine("Shortest Job First Queue:");
            foreach (var process in sjfQueue.Keys)
            {
                Console.WriteLine(process);
            }

            Console.WriteLine("Priority Queue:");
            foreach (var process in priorityQueue)
            {
                Console.WriteLine(process.process);
            }

            Console.WriteLine("Multi-Level Feedback Queue:");
            foreach (var level in mlfqQueues.Keys)
            {
                Console.WriteLine($"Level {level}:");
                foreach (var process in mlfqQueues[level])
                {
                    Console.WriteLine(process);
                }
            }
        }

        private void SendMessage(string sender, string receiver, string message)
        {
            string communicationKey = $"{sender}->{receiver}";
            interProcessCommunication[communicationKey] = message;
            Console.WriteLine($"Message from '{sender}' to '{receiver}': {message}");
        }

        private void DisplayMemoryInfo()
        {
            Console.WriteLine("Memory Information:");
            foreach (var entry in processMemory)
            {
                Console.WriteLine($"Process: {entry.Key}, Memory: {entry.Value} KB");
            }
        }

        private void HandleEdgeTaskCommands(string[] commandParts)
        {
            if (commandParts.Length == 2 && commandParts[1] == "list")
            {
                Console.WriteLine("Edge tasks:");
                foreach (var task in edgeTasks)
                {
                    Console.WriteLine(task);
                }
            }
            else if (commandParts.Length == 3 && commandParts[1] == "add")
            {
                string task = commandParts[2];
                edgeTasks.Add(task);
                Console.WriteLine($"Edge task '{task}' added.");
            }
            else if (commandParts.Length == 3 && commandParts[1] == "remove")
            {
                string task = commandParts[2];
                if (edgeTasks.Remove(task))
                {
                    Console.WriteLine($"Edge task '{task}' removed.");
                }
                else
                {
                    Console.WriteLine($"Edge task '{task}' not found.");
                }
            }
            else
            {
                Console.WriteLine("Invalid edge task command.");
            }
        }

        private void ShowFileSize(string fileName)
        {
            if (fileSystem.ContainsKey(fileName))
            {
                Console.WriteLine($"Size of file '{fileName}': {fileSystem[fileName].size} bytes");
            }
            else
            {
                Console.WriteLine($"File '{fileName}' not found.");
            }
        }

        private void SaveFileSystem()
        {
            try
            {
                var file = VFSManager.GetFile(FileSystemPath);
                if (file != null)
                {
                    VFSManager.DeleteFile(FileSystemPath);
                }

                file = VFSManager.CreateFile(FileSystemPath);
                using (var fs = file.GetFileStream())
                using (var writer = new StreamWriter(fs))
                {
                    foreach (var entry in fileSystem)
                    {
                        writer.WriteLine($"{entry.Key}|{entry.Value.size}|{entry.Value.content}");
                    }
                }
                Console.WriteLine("File system saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving file system: {ex.Message}");
            }
        }

        private void LoadFileSystem()
        {
            try
            {
                var file = VFSManager.GetFile(FileSystemPath);
                if (file == null)
                {
                    Console.WriteLine("No file system found to load.");
                    return;
                }

                using (var fs = file.GetFileStream())
                using (var reader = new StreamReader(fs))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        var parts = line.Split('|');
                        if (parts.Length == 3)
                        {
                            var fileName = parts[0];
                            var size = int.Parse(parts[1]);
                            var content = parts[2];
                            fileSystem[fileName] = (content, size);
                        }
                    }
                }
                Console.WriteLine("File system loaded successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading file system: {ex.Message}");
            }
        }
    }
}